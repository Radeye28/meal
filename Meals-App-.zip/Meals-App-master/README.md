This project is a meal finder which displays the meals as their is text typed in the search bar.
Features included:
1. Add any meal to favourites or remove it from favourites on clicking the favourite icon
2. Click on more details of the meal to get more details about the meal preparation along with the video link
3. Display any random meal on clicking on the random icon
4. My favourite list is stored in the browser even if we refresh or quit the browser

API:https://www.themealdb.com/api.php
This project is used making HTML,CSS and vanilla JS without use of any library.